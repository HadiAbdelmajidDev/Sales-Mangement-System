package com.sales.management.system.seller.service;

import com.sales.management.system.product.dto.ProductRequestDTO;
import com.sales.management.system.product.model.Product;
import com.sales.management.system.seller.dto.SellerRequestDTO;
import com.sales.management.system.seller.model.Seller;

import java.util.List;
import java.util.UUID;

public interface SellerService {
    List<Seller> getAllSellers();
    Seller getSellerById(UUID id) throws Exception;
    Seller createSeller(SellerRequestDTO sellerRequestDTO);
}

package com.sales.management.system.sale.dto;

import com.sales.management.system.saletransaction.dto.SaleTransactionRequestDTO;
import lombok.Data;
import java.util.List;
import java.util.UUID;

@Data
public class SaleRequestDTO {
    private UUID client;

    private UUID seller;

    private List<SaleTransactionRequestDTO> transactions;
}

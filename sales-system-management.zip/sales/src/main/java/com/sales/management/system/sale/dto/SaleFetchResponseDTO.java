package com.sales.management.system.sale.dto;


import com.sales.management.system.client.model.Client;
import com.sales.management.system.seller.model.Seller;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class SaleFetchResponseDTO {
    private UUID id;
    private Client client;
    private Seller seller;
    private BigDecimal total;
}

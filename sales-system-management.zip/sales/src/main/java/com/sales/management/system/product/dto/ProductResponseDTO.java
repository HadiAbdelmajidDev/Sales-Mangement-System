package com.sales.management.system.product.dto;

import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
public class ProductResponseDTO {
    private UUID id;
    private String name;
    private String description;
    private String category;
    private Date creationDate;
}

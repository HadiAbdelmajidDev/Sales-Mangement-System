package com.sales.management.system.client.model;

import lombok.Data;

import javax.persistence.*;
import java.util.UUID;
@Entity
@Data
public class Client {
    @Id
    @Column(name = "id")
    private UUID id;
    @Column(name = "first_name")
    private String firstName;
    @Column(name = "last_name")
    private String lastName;
    @Column(name = "mobile")
    private String mobile;
}

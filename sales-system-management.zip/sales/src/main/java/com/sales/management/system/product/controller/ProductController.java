package com.sales.management.system.product.controller;

import com.sales.management.system.CommonUtils;
import com.sales.management.system.product.dto.ProductRequestDTO;
import com.sales.management.system.product.dto.ProductResponseDTO;
import com.sales.management.system.product.model.Product;
import com.sales.management.system.product.service.ProductService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private ProductService productService;
    @Autowired
    private ModelMapper modelMapper;

    @GetMapping
    public List<ProductResponseDTO> getAllProducts() {
        return CommonUtils.mapList(productService.getAllProducts(),ProductResponseDTO.class,modelMapper);
    }

    @GetMapping("/{id}")
    public ProductResponseDTO getProductById(@PathVariable UUID id) throws Exception {
        return modelMapper.map(productService.getProductById(id),ProductResponseDTO.class);
    }

    @PostMapping("/save")
    public ProductResponseDTO createProduct(@RequestBody ProductRequestDTO productRequestDTO) {
        return modelMapper.map(productService.createProduct(productRequestDTO), ProductResponseDTO.class);
    }

    @PutMapping("/update/{id}")
    public ProductResponseDTO updateProduct(@PathVariable UUID id, @RequestBody ProductRequestDTO productRequestDTO) throws Exception {
        return modelMapper.map(productService.updateProduct(id, productRequestDTO), ProductResponseDTO.class);
    }


}
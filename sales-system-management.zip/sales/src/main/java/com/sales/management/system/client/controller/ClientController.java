package com.sales.management.system.client.controller;

import com.sales.management.system.CommonUtils;
import com.sales.management.system.client.dto.ClientRequestDTO;
import com.sales.management.system.client.dto.ClientResponseDTO;
import com.sales.management.system.client.model.Client;
import com.sales.management.system.client.service.ClientService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/clients")
public class ClientController {
    @Autowired
    private ClientService clientService;
    @Autowired
    private ModelMapper modelMapper;

    @GetMapping
    public List<ClientResponseDTO> getAllClients() {
        return CommonUtils.mapList(clientService.getAllClients(),ClientResponseDTO.class,modelMapper);
    }

    @GetMapping("/{id}")
    public ClientResponseDTO getClientById(@PathVariable UUID id) throws Exception {
        return modelMapper.map(clientService.getClientById(id),ClientResponseDTO.class);
    }

    @PostMapping("/save")
    public ClientResponseDTO createClient(@RequestBody ClientRequestDTO clientRequestDTO) {
        return modelMapper.map(clientService.createClient(clientRequestDTO), ClientResponseDTO.class);
    }

    @PutMapping("/update/{id}")
    public ClientResponseDTO updateProduct(@PathVariable UUID id, @RequestBody ClientRequestDTO clientRequestDTO) throws Exception {
        return modelMapper.map(clientService.updateClient(id, clientRequestDTO), ClientResponseDTO.class);
    }



}

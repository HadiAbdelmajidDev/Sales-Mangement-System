package com.sales.management.system.saletransaction.dto;

import com.sales.management.system.product.model.Product;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class SaleTransactionResponseDTO {
    private UUID id;

    private Product product;

    private BigDecimal quantity;

    private BigDecimal price;
}

package com.sales.management.system.client.dto;

import lombok.Data;

import java.util.UUID;

@Data
public class ClientResponseDTO {
    private UUID id;
    private String firstName;
    private String lastName;
    private String mobile;
}

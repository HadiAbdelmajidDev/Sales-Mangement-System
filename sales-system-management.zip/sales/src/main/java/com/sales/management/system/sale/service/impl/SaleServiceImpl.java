package com.sales.management.system.sale.service.impl;

import com.sales.management.system.CommonUtils;
import com.sales.management.system.client.model.Client;
import com.sales.management.system.client.repository.ClientRepository;
import com.sales.management.system.product.model.Product;
import com.sales.management.system.product.repository.ProductRepository;
import com.sales.management.system.sale.dto.SaleRequestDTO;
import com.sales.management.system.sale.dto.SaleUpdateRequestDTO;
import com.sales.management.system.sale.model.Sale;
import com.sales.management.system.sale.repository.SaleRepository;
import com.sales.management.system.sale.service.SaleService;
import com.sales.management.system.saletransaction.dto.SaleTransactionRequestDTO;
import com.sales.management.system.saletransaction.model.SaleTransaction;
import com.sales.management.system.saletransaction.repository.SaleTransactionRepository;
import com.sales.management.system.seller.model.Seller;
import com.sales.management.system.seller.repository.SellerRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class SaleServiceImpl implements SaleService {
    @Autowired
    ClientRepository clientRepository;

    @Autowired
    SellerRepository sellerRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    SaleRepository saleRepository;

    @Autowired
    SaleTransactionRepository saleTransactionRepository;

    @Override
    public Sale createSale(SaleRequestDTO saleRequestDTO) throws Exception {
        log.info("Creating sale...");
        BigDecimal total = new BigDecimal(BigInteger.ZERO);
        List<SaleTransaction> transactions = new ArrayList<SaleTransaction>();

        Optional<Client> client = clientRepository.findById(saleRequestDTO.getClient());
        if (!client.isPresent()) {
            log.error("Client not found with id {}",saleRequestDTO.getClient());
            throw new Exception("Client not found");
        }

        Optional<Seller> seller = sellerRepository.findById(saleRequestDTO.getSeller());
        if (!seller.isPresent()) {
            log.error("Seller not found with id {}.",saleRequestDTO.getSeller());
            throw new Exception("Seller not found");
        }

        Sale sale = new Sale();
        sale.setId(UUID.randomUUID());
        sale.setClient(client.get());
        sale.setSeller(seller.get());
        sale = saleRepository.save(sale);

        if (null != saleRequestDTO.getTransactions() && !saleRequestDTO.getTransactions().isEmpty()) {
            for (SaleTransactionRequestDTO transaction : saleRequestDTO.getTransactions()) {
                SaleTransaction saleTransaction = new SaleTransaction();
                saleTransaction.setSale(sale);

                Optional<Product> product = productRepository.findById(transaction.getProduct());
                if (!product.isPresent()) {
                    log.error("Product not found with id {}",transaction.getProduct());
                    throw new Exception("Product not found");
                }

                saleTransaction.setProduct(product.get());
                saleTransaction.setPrice(transaction.getPrice());
                saleTransaction.setQuantity(transaction.getQuantity());
                saleTransaction.setId(UUID.randomUUID());
                saleTransactionRepository.save(saleTransaction);

                total = total.add(transaction.getPrice().multiply(transaction.getQuantity()));
                transactions.add(saleTransaction);
            }

            sale.setTotal(total);
            sale.setTransactions(transactions);
            saleRepository.save(sale);
        }

        log.info("Sale created successfully.");
        return sale;
    }

    @Override
    public Sale addTransaction(UUID saleId, SaleTransactionRequestDTO saleTransactionRequestDTO) throws Exception {
        log.info("Adding transaction to sale...");

        Optional<Sale> sale = saleRepository.findById(saleId);
        if (!sale.isPresent()) {
            log.error("Sale not found with id {}", saleId);
            throw new Exception("Sale not found");
        }

        SaleTransaction saleTransaction = new SaleTransaction();
        saleTransaction.setId(UUID.randomUUID());
        saleTransaction.setQuantity(saleTransactionRequestDTO.getQuantity());

        Optional<Product> product = productRepository.findById(saleTransactionRequestDTO.getProduct());
        if (!product.isPresent()) {
            log.error("Product not with id {}",saleTransactionRequestDTO.getProduct());
            throw new Exception("Product not found");
        }

        saleTransaction.setProduct(product.get());
        saleTransaction.setPrice(saleTransactionRequestDTO.getPrice());
        saleTransaction.setSale(sale.get());
        saleTransactionRepository.save(saleTransaction);

        sale.get().setTotal(sale.get().getTotal().add(saleTransaction.getPrice().multiply(saleTransaction.getQuantity())));
        sale.get().getTransactions().add(saleTransaction);
        saleRepository.save(sale.get());

        log.info("Transaction added to sale successfully.");
        return sale.get();
    }

    @Override
    public List<Sale> getAllSales() {
        log.info("Fetching all sales...");
        return saleRepository.findAll();
    }

    @Override
    public Sale updateSale(UUID transactionId, SaleUpdateRequestDTO saleUpdateRequestDTO) throws Exception {
        log.info("Updating sale...");

        Optional<SaleTransaction> saleTransaction = saleTransactionRepository.findById(transactionId);
        if (!saleTransaction.isPresent()) {
            log.error("Transaction not found with id {}", transactionId);
            throw new Exception("Transaction not found");
        }

        BeanUtils.copyProperties(saleUpdateRequestDTO, saleTransaction, CommonUtils.getNullPropertyNames(saleUpdateRequestDTO));
        saleTransactionRepository.save(saleTransaction.get());

        Optional<Sale> sale = saleRepository.findById(saleTransaction.get().getSale().getId());
        sale.get().setTotal(sale.get().getTotal().add(saleTransaction.get().getQuantity().multiply(saleTransaction.get().getPrice())));
        saleRepository.save(sale.get());

        log.info("Sale updated successfully.");
        return sale.get();
    }
}
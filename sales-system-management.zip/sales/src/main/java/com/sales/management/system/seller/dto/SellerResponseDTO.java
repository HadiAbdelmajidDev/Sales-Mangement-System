package com.sales.management.system.seller.dto;


import lombok.Data;
import java.util.UUID;

@Data
public class SellerResponseDTO {
    private UUID id;
    private String name;
}

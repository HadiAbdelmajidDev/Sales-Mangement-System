package com.sales.management.system.sale.model;

import com.sales.management.system.client.model.Client;
import com.sales.management.system.saletransaction.model.SaleTransaction;
import com.sales.management.system.seller.model.Seller;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;
@Entity
@Data
public class Sale {
    @Id
    @Column(name = "id")
    private UUID id;
    @Column(name = "creation_date")
    @CreationTimestamp
    private Date creationDate;

    @ManyToOne
    @JoinColumn(name = "client_id")
    private Client client;

    @ManyToOne
    @JoinColumn(name = "seller_id")
    private Seller seller;

    @Column(name = "total")
    private BigDecimal total;

    @OneToMany(mappedBy = "sale", cascade = CascadeType.ALL)
    private List<SaleTransaction> transactions;
}

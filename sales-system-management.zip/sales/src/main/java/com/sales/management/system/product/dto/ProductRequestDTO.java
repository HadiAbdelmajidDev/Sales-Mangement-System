package com.sales.management.system.product.dto;

import lombok.Data;
import java.util.UUID;

@Data
public class ProductRequestDTO {
    private String name;
    private String description;
    private String category;
}

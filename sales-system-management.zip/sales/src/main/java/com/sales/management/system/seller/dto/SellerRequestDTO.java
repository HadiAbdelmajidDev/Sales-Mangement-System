package com.sales.management.system.seller.dto;

import lombok.Data;

import javax.persistence.Column;
@Data
public class SellerRequestDTO {
    private String name;
}

package com.sales.management.system.seller.model;

import lombok.Data;

import javax.persistence.*;
import java.util.UUID;

@Entity
@Data
public class Seller {
    @Id
    @Column(name = "id")
    private UUID id;
    @Column(name = "name")
    private String name;

}

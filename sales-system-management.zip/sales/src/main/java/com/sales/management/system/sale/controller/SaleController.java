package com.sales.management.system.sale.controller;

import com.sales.management.system.CommonUtils;
import com.sales.management.system.sale.dto.SaleFetchResponseDTO;
import com.sales.management.system.sale.dto.SaleRequestDTO;
import com.sales.management.system.sale.dto.SaleResponseDTO;
import com.sales.management.system.sale.dto.SaleUpdateRequestDTO;
import com.sales.management.system.sale.service.SaleService;
import com.sales.management.system.saletransaction.dto.SaleTransactionRequestDTO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/sales")
public class SaleController {
    @Autowired
    private SaleService saleService;
    @Autowired
    private ModelMapper modelMapper;
    @PostMapping("/create")
    public SaleResponseDTO createSale(@RequestBody SaleRequestDTO saleRequestDTO) throws Exception {
        return modelMapper.map(saleService.createSale(saleRequestDTO), SaleResponseDTO.class);
    }
    @PutMapping("/add-transaction/{saleId}")
    public SaleResponseDTO addTransaction(@RequestBody SaleTransactionRequestDTO saleTransactionRequestDTO,@PathVariable UUID saleId) throws Exception {
        return modelMapper.map(saleService.addTransaction(saleId,saleTransactionRequestDTO), SaleResponseDTO.class);
    }
    @PutMapping("/update/{txnId}")
    public SaleResponseDTO updateSale(@RequestBody SaleUpdateRequestDTO saleUpdateRequestDTO, @PathVariable UUID txnId) throws Exception {
        return modelMapper.map(saleService.updateSale(txnId,saleUpdateRequestDTO), SaleResponseDTO.class);
    }
    @GetMapping
    public List<SaleFetchResponseDTO> getAllProducts() {
        return CommonUtils.mapList(saleService.getAllSales(),SaleFetchResponseDTO.class,modelMapper);
    }

}

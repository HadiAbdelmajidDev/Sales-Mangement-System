package com.sales.management.system.sale.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SaleUpdateRequestDTO {
    private BigDecimal quantity;
    private BigDecimal price;

}

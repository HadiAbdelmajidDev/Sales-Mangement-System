package com.sales.management.system.seller.controller;


import com.sales.management.system.CommonUtils;
import com.sales.management.system.seller.dto.SellerRequestDTO;
import com.sales.management.system.seller.dto.SellerResponseDTO;
import com.sales.management.system.seller.service.SellerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;


@RestController
@RequestMapping("/seller")
public class SellerController {

    @Autowired
    private SellerService sellerService;
    @Autowired
    private ModelMapper modelMapper;

    @GetMapping
    public List<SellerResponseDTO> getAllSellers() {
        return CommonUtils.mapList(sellerService.getAllSellers(),SellerResponseDTO.class,modelMapper);
    }

    @GetMapping("/{id}")
    public SellerResponseDTO getSellerById(@PathVariable UUID id) throws Exception {
        return modelMapper.map(sellerService.getSellerById(id),SellerResponseDTO.class);
    }

    @PostMapping("/save")
    public SellerResponseDTO createSeller(@RequestBody SellerRequestDTO sellerRequestDTO) {
        return modelMapper.map(sellerService.createSeller(sellerRequestDTO), SellerResponseDTO.class);
    }

}

package com.sales.management.system.saletransaction.repository;

import com.sales.management.system.sale.model.Sale;
import com.sales.management.system.saletransaction.model.SaleTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface SaleTransactionRepository extends JpaRepository<SaleTransaction, UUID> {
}

package com.sales.management.system.product.service.impl;


import com.sales.management.system.CommonUtils;
import com.sales.management.system.product.dto.ProductRequestDTO;
import com.sales.management.system.product.model.Product;
import com.sales.management.system.product.repository.ProductRepository;
import com.sales.management.system.product.service.ProductService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.modelmapper.ModelMapper;


import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product getProductById(UUID id) throws Exception {
        return productRepository.findById(id)
                .orElseThrow(() -> new Exception("Product not found with id: " + id));
    }

    @Override
    public Product createProduct(ProductRequestDTO productRequestDTO) {
        Product product = modelMapper.map(productRequestDTO,Product.class);
        product.setId(UUID.randomUUID());
        return productRepository.save(product);
    }

    @Override
    public Product updateProduct(UUID id, ProductRequestDTO updatedProduct) throws Exception {
        Product existingProduct = getProductById(id);
        if(null == existingProduct){
           throw new Exception("product does not exist");
        }
        BeanUtils.copyProperties(updatedProduct, existingProduct, CommonUtils.getNullPropertyNames(updatedProduct));
        return productRepository.save(existingProduct);
    }




}

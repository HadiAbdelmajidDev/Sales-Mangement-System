package com.sales.management.system.client.service.impl;

import com.sales.management.system.CommonUtils;
import com.sales.management.system.client.dto.ClientRequestDTO;
import com.sales.management.system.client.model.Client;
import com.sales.management.system.client.repository.ClientRepository;
import com.sales.management.system.client.service.ClientService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
@Service
public class ClientServiceImpl implements ClientService {
    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<Client> getAllClients() {
        return clientRepository.findAll();
    }

    @Override
    public Client getClientById(UUID id) throws Exception {
        return clientRepository.findById(id)
                .orElseThrow(() -> new Exception("Product not found with id: " + id));
    }

    @Override
    public Client createClient(ClientRequestDTO clientRequestDTO) {
        Client client = modelMapper.map(clientRequestDTO,Client.class);
        client.setId(UUID.randomUUID());
        return clientRepository.save(client);
    }

    @Override
    public Client updateClient(UUID id, ClientRequestDTO clientRequestDTO) throws Exception {
        Client existingclient = getClientById(id);
        if(null == existingclient){
            throw new Exception("client does not exist");
        }
        BeanUtils.copyProperties(clientRequestDTO, existingclient, CommonUtils.getNullPropertyNames(clientRequestDTO));
        return clientRepository.save(existingclient);
    }



}


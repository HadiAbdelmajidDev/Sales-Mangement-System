package com.sales.management.system.client.dto;

import lombok.Data;

import javax.persistence.Column;
@Data
public class ClientRequestDTO {
    private String firstName;
    private String lastName;
    private String mobile;
}

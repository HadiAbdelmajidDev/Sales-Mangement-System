package com.sales.management.system.seller.service.impl;
import com.sales.management.system.seller.dto.SellerRequestDTO;
import com.sales.management.system.seller.model.Seller;
import com.sales.management.system.seller.repository.SellerRepository;
import com.sales.management.system.seller.service.SellerService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
@Service
public class SellerServiceImpl implements SellerService {
    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<Seller> getAllSellers() {
        return sellerRepository.findAll();
    }

    @Override
    public Seller getSellerById(UUID id) throws Exception {
        return sellerRepository.findById(id)
                .orElseThrow(() -> new Exception("Seller not found with id: " + id));
    }

    @Override
    public Seller createSeller(SellerRequestDTO sellerRequestDTO) {
        Seller seller = modelMapper.map(sellerRequestDTO,Seller.class);
        seller.setId(UUID.randomUUID());
        return sellerRepository.save(seller);
    }

}

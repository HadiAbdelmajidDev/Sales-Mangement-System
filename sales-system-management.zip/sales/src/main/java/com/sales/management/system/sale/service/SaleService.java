package com.sales.management.system.sale.service;

import com.sales.management.system.product.model.Product;
import com.sales.management.system.sale.dto.SaleRequestDTO;
import com.sales.management.system.sale.dto.SaleUpdateRequestDTO;
import com.sales.management.system.sale.model.Sale;
import com.sales.management.system.saletransaction.dto.SaleTransactionRequestDTO;
import com.sales.management.system.saletransaction.model.SaleTransaction;

import java.util.List;
import java.util.UUID;

public interface SaleService {


    Sale createSale(SaleRequestDTO saleRequestDTO) throws Exception;

    Sale addTransaction(UUID saleId, SaleTransactionRequestDTO saleTransactionRequestDTO) throws Exception;

    List<Sale> getAllSales();

    Sale updateSale(UUID transactionId, SaleUpdateRequestDTO saleUpdateRequestDTO) throws Exception;
}

package com.sales.management.system.saletransaction.model;

import com.sales.management.system.product.model.Product;
import com.sales.management.system.sale.model.Sale;
import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Data
public class SaleTransaction {
    @Id
    @Column(name = "id")
    private UUID id;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    @Column(name = "quantity")
    private BigDecimal quantity;

    @Column(name = "price")
    private BigDecimal price;

    @ManyToOne(targetEntity = Sale.class)
    @JoinColumn(name = "sale_id")
    private Sale sale;
}

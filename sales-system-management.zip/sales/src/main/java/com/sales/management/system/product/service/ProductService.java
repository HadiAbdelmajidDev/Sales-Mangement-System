package com.sales.management.system.product.service;


import com.sales.management.system.product.dto.ProductRequestDTO;
import com.sales.management.system.product.model.Product;

import java.util.List;
import java.util.UUID;

public interface ProductService {
    List<Product> getAllProducts();
    Product getProductById(UUID id) throws Exception;
    Product createProduct(ProductRequestDTO productRequestDTO);
    Product updateProduct(UUID id, ProductRequestDTO updatedProduct) throws Exception;
}

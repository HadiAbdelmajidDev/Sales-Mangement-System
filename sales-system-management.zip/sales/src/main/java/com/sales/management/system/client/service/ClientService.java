package com.sales.management.system.client.service;
import com.sales.management.system.client.dto.ClientRequestDTO;
import com.sales.management.system.client.model.Client;


import java.util.List;
import java.util.UUID;

public interface ClientService {
    List<Client> getAllClients();
    Client getClientById(UUID id) throws Exception;
    Client createClient(ClientRequestDTO clientRequestDTO);
    Client updateClient(UUID id, ClientRequestDTO updatedclient) throws Exception;
}

